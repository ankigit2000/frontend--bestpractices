import { AfterViewInit, Directive, ElementRef, Input, OnChanges, TemplateRef, ViewContainerRef } from '@angular/core';
import { CredentialsService } from '@app/auth';

@Directive({
  selector: '[appAuthorization]',
})
export class AuthorizationDirective implements OnChanges {
  @Input() roles: string[] = [];

  constructor(
    private view: ViewContainerRef,
    private template: TemplateRef<any>,
    private credService: CredentialsService
  ) {}

  ngOnChanges() {
    let role = '';
    if (this.credService.credentials) {
      role = this.credService.credentials.role;
    }
    if (this.credService.credentials && this.roles.includes(role)) {
      this.view.createEmbeddedView(this.template);
    } else {
      this.view.clear();
    }
  }
}
