import { AuthorizationDirective } from './authorization.directive';

describe('AuthorizationDirective', () => {
  it('should create an instance', () => {
    const directive = new AuthorizationDirective();
    expect(directive).toBeTruthy();
  });
});
