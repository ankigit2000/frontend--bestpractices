import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-restaurant-details',
  templateUrl: './restaurant-details.component.html',
  styleUrls: ['./restaurant-details.component.scss']
})
export class RestaurantDetailsComponent implements OnInit {
  restarurantId: string='';
  constructor(
    private route: ActivatedRoute
  ) {
    this.restarurantId = this.route.snapshot.paramMap.get('id') || '';
  }

  ngOnInit(): void {
  }

}
