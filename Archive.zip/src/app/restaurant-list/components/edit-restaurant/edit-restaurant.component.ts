import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RestaurantListService } from '@app/restaurant-list/restaurant-list.service';

@Component({
  selector: 'app-edit-restaurant',
  templateUrl: './edit-restaurant.component.html',
  styleUrls: ['./edit-restaurant.component.scss']
})
export class EditRestaurantComponent implements OnInit {
  id: string = '';
  restDetails = {};
  detailsFetched = false;
  constructor(
    private route: ActivatedRoute,
    private restaurantListService: RestaurantListService
  ) {
    this.id = this.route.snapshot.queryParamMap.get('id') as string;
  }

  ngOnInit(): void {
    this.getRestarutantDetails();
  }

  getRestarutantDetails() {
    this.restaurantListService.fetchRestaurantById(this.id).subscribe({
      next: (data) => {
        console.log(data)
        this.restDetails = data?.data;
        this.detailsFetched = true;
      }
    })
  }

}
