import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { RestaurantListDALService } from './restaurant-list-dal.service';

@Injectable({
  providedIn: 'root'
})
export class RestaurantListService {

  constructor(
    private restaurantDALService: RestaurantListDALService
  ) { }
  /**
   * Method to get the restaurants list
   * @returns restaurants list
   */
  getRestaurants(searchString: string): Observable<any> {
    return new Observable( observer => {
      this.restaurantDALService.fetchRestaurants(searchString).subscribe({
        next: (data) => {
          observer.next(this.formatRestaurants(data));
        },
        error: (error) => {
          observer.error(error);
        }
      })
    })
  }
  addRestaurant(value: any): Observable<any> {
    value.id = Math.random()*100000 + 1;
    value.address = value.city + ' ' + value.state; 
    value.data = value;
    return this.restaurantDALService.addRestaurant(value);
  }
  updateRestaurant(id: string, value: any): Observable<any> {
    value.address = value.city + ' ' + value.state; 
    value.data = value;
    return this.restaurantDALService.updateRestaurantById(id, value);
  }
  fetchRestaurantById(id: string): Observable<any> {
    return new Observable( observer => {
      this.restaurantDALService.fetchRestaurantById(id).subscribe({
        next: (data) => {
          observer.next(data);
        }
      })
    })
  }
  deleteRestaurant(id: string): Observable<any> {
    return this.restaurantDALService.deleteRestaurant(id);
  }
  /**
   * Method to format the restaurants data
   * @param restaurantList restaurants list
   * @returns formatted restaurants list
   */
  private formatRestaurants(restaurantList: any): any {
    return restaurantList;
  }
}
